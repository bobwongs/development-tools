//
//  BWMainVC.swift
//  BWMacOSStudySwift
//
//  Created by BobWong on 17/1/11.
//  Copyright © 2017年 BobWongStudio. All rights reserved.
//

import Cocoa

class BWMainVC: NSViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do view setup here.
    }
    
}

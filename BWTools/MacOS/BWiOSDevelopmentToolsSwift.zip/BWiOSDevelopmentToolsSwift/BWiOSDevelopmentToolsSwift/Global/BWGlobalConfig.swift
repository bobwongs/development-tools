//
//  BWGlobalConfig.swift
//  BWiOSDevelopmentToolsSwift
//
//  Created by BobWong on 2017/1/18.
//  Copyright © 2017年 BobWongStudio. All rights reserved.
//

// ---------- Global Parameters ----------

let kCopyRight = "kCopyRight"
let kProject = "kProject"
let kAuthor = "kAuthor"
let kPrefix = "kPrefix"
let kImportFile = "kImportFile"
let kBasicVC = "kBasicVC"
let kModule = "kModule"

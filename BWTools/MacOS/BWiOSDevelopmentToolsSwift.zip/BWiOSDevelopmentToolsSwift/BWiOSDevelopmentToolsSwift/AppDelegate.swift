//
//  AppDelegate.swift
//  BWiOSDevelopmentToolsSwift
//
//  Created by BobWong on 17/1/13.
//  Copyright © 2017年 BobWongStudio. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {



    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
    }

    func applicationWillTerminate(_ aNotification: Notification) {
        // Insert code here to tear down your application
    }


}

